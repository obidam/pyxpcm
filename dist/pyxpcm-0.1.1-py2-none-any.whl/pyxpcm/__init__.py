name = "pyxpcm"

from pcmv5 import PCM as pcm
import dummy_datasets as datasets
from . import stats
from . import plot